extends CharacterBody3D
class_name ArenaFighter

@export var fighter_name := "Nova"
@export var move_speed := 7.0
@export var max_health := 100.0
var health := 100.0
var attack_cooldown := 0.0
var is_player := false
var body_mesh: MeshInstance3D
var health_bar: ProgressBar

func setup(display_name: String, tint: Color, player_controlled: bool) -> void:
    fighter_name = display_name
    is_player = player_controlled
    health = max_health

    var shape := CapsuleShape3D.new()
    shape.radius = 0.55
    shape.height = 2.0
    var collision := CollisionShape3D.new()
    collision.shape = shape
    add_child(collision)

    body_mesh = MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.55
    capsule.height = 2.0
    body_mesh.mesh = capsule
    var material := StandardMaterial3D.new()
    material.albedo_color = tint
    material.metallic = 0.28
    material.roughness = 0.32
    body_mesh.material_override = material
    body_mesh.position.y = 1.0
    add_child(body_mesh)

    var aura := MeshInstance3D.new()
    var aura_mesh := SphereMesh.new()
    aura_mesh.radius = 0.82
    aura_mesh.height = 1.64
    aura.mesh = aura_mesh
    var aura_mat := StandardMaterial3D.new()
    aura_mat.albedo_color = Color(tint.r, tint.g, tint.b, 0.16)
    aura_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    aura_mat.emission_enabled = true
    aura_mat.emission = tint
    aura_mat.emission_energy_multiplier = 0.8
    aura.material_override = aura_mat
    aura.position.y = 1.0
    add_child(aura)

func _physics_process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    if not is_player:
        return
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if input_dir.length() > 1.0:
        input_dir = input_dir.normalized()
    var direction := Vector3(input_dir.x, 0.0, input_dir.y)
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    if direction.length() > 0.1:
        look_at(global_position + direction, Vector3.UP)
    move_and_slide()

func take_damage(amount: float) -> void:
    health = maxf(0.0, health - amount)
    if body_mesh:
        body_mesh.scale = Vector3(1.15, 0.9, 1.15)
        var tween := create_tween()
        tween.tween_property(body_mesh, "scale", Vector3.ONE, 0.18)
