extends Node3D

const FighterScript = preload("res://scripts/fighter.gd")
const SERVER_PORT := 24567
const MAX_PLAYERS := 8

var hero: ArenaFighter
var rival: ArenaFighter
var status_label: Label
var health_label: Label
var attack_button: Button
var host_field: LineEdit
var network_peer: ENetMultiplayerPeer
var attack_timer := 0.0

func _ready() -> void:
    _build_world()
    _build_fighters()
    _build_ui()
    _setup_network_mode()

func _process(delta: float) -> void:
    attack_timer = maxf(0.0, attack_timer - delta)
    if rival and hero:
        var distance := hero.global_position.distance_to(rival.global_position)
        if distance > 2.2:
            var dir := (hero.global_position - rival.global_position).normalized()
            rival.velocity.x = dir.x * 2.2
            rival.velocity.z = dir.z * 2.2
            rival.look_at(Vector3(hero.global_position.x, rival.global_position.y, hero.global_position.z), Vector3.UP)
            rival.move_and_slide()
        if distance < 1.8 and attack_timer <= 0.0:
            hero.take_damage(4.0)
            attack_timer = 1.4
    if health_label and hero:
        health_label.text = "NOVA  %d HP" % int(hero.health)

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.025, 0.035, 0.075)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.45, 0.52, 0.78)
    env.ambient_light_energy = 0.7
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.6
    sun.shadow_enabled = true
    add_child(sun)

    var floor := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(32, 32)
    floor.mesh = plane
    var floor_mat := StandardMaterial3D.new()
    floor_mat.albedo_color = Color(0.075, 0.095, 0.16)
    floor_mat.metallic = 0.35
    floor_mat.roughness = 0.7
    floor.material_override = floor_mat
    add_child(floor)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 9, 13)
    camera.rotation_degrees = Vector3(-28, 0, 0)
    camera.current = true
    add_child(camera)

    for i in range(12):
        var pillar := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(0.35, 3.2, 0.35)
        pillar.mesh = box
        var pm := StandardMaterial3D.new()
        pm.albedo_color = Color(0.12, 0.19, 0.34)
        pm.emission_enabled = true
        pm.emission = Color(0.08, 0.25, 0.8)
        pm.emission_energy_multiplier = 0.45
        pillar.material_override = pm
        var angle := TAU * float(i) / 12.0
        pillar.position = Vector3(cos(angle) * 11.0, 1.6, sin(angle) * 11.0)
        add_child(pillar)

func _build_fighters() -> void:
    hero = FighterScript.new()
    hero.setup("Nova", Color(0.12, 0.62, 1.0), true)
    hero.position = Vector3(-2.5, 0, 0)
    add_child(hero)

    rival = FighterScript.new()
    rival.setup("Void", Color(0.95, 0.16, 0.34), false)
    rival.position = Vector3(2.5, 0, 0)
    add_child(rival)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    var title := Label.new()
    title.text = "AETHER ARENA"
    title.position = Vector2(28, 18)
    title.add_theme_font_size_override("font_size", 30)
    title.add_theme_color_override("font_color", Color(0.45, 0.8, 1.0))
    root.add_child(title)

    health_label = Label.new()
    health_label.text = "NOVA  100 HP"
    health_label.position = Vector2(30, 65)
    health_label.add_theme_font_size_override("font_size", 20)
    root.add_child(health_label)

    status_label = Label.new()
    status_label.text = "OFFLINE • تدريب"
    status_label.position = Vector2(30, 100)
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.add_theme_color_override("font_color", Color(0.75, 0.82, 0.95))
    root.add_child(status_label)

    var connect_panel := HBoxContainer.new()
    connect_panel.position = Vector2(28, 145)
    root.add_child(connect_panel)
    host_field = LineEdit.new()
    host_field.placeholder_text = "عنوان الخادم"
    host_field.text = "127.0.0.1"
    host_field.custom_minimum_size = Vector2(190, 42)
    connect_panel.add_child(host_field)
    var connect_btn := Button.new()
    connect_btn.text = "اتصال أونلاين"
    connect_btn.custom_minimum_size = Vector2(150, 42)
    connect_btn.pressed.connect(_connect_online)
    connect_panel.add_child(connect_btn)

    var move_label := Label.new()
    move_label.text = "W A S D / عصا الحركة"
    move_label.position = Vector2(30, 650)
    move_label.add_theme_font_size_override("font_size", 17)
    root.add_child(move_label)

    attack_button = Button.new()
    attack_button.text = "ضربة\nATTACK"
    attack_button.position = Vector2(1080, 555)
    attack_button.size = Vector2(150, 120)
    attack_button.add_theme_font_size_override("font_size", 23)
    attack_button.pressed.connect(_attack)
    root.add_child(attack_button)

    var special := Button.new()
    special.text = "قوة خارقة"
    special.position = Vector2(930, 600)
    special.size = Vector2(130, 70)
    special.pressed.connect(_special_attack)
    root.add_child(special)

func _attack() -> void:
    if hero and rival and hero.global_position.distance_to(rival.global_position) < 3.2:
        rival.take_damage(12.0)
        status_label.text = "ضربة ناجحة! Void: %d HP" % int(rival.health)
    else:
        status_label.text = "اقترب من الخصم لتنفيذ الضربة"

func _special_attack() -> void:
    if hero and rival and hero.global_position.distance_to(rival.global_position) < 5.0:
        rival.take_damage(28.0)
        status_label.text = "✦ انفجار الطاقة! ضرر خارق"
    else:
        status_label.text = "لا يوجد خصم ضمن مدى الطاقة"

func _setup_network_mode() -> void:
    if OS.get_cmdline_user_args().has("--server"):
        _start_server()

func _start_server() -> void:
    network_peer = ENetMultiplayerPeer.new()
    var err := network_peer.create_server(SERVER_PORT, MAX_PLAYERS)
    if err == OK:
        multiplayer.multiplayer_peer = network_peer
        print("Aether Arena server listening on UDP ", SERVER_PORT)
    else:
        push_error("Could not start server: %s" % err)

func _connect_online() -> void:
    var address := host_field.text.strip_edges()
    if address.is_empty():
        status_label.text = "أدخل عنوان الخادم أولاً"
        return
    network_peer = ENetMultiplayerPeer.new()
    var err := network_peer.create_client(address, SERVER_PORT)
    if err != OK:
        status_label.text = "تعذر بدء الاتصال: %s" % err
        return
    multiplayer.multiplayer_peer = network_peer
    multiplayer.connected_to_server.connect(func(): status_label.text = "متصل بالخادم")
    multiplayer.connection_failed.connect(func(): status_label.text = "فشل الاتصال بالخادم")
    multiplayer.server_disconnected.connect(func(): status_label.text = "انقطع الاتصال")
    status_label.text = "جارٍ الاتصال..."
